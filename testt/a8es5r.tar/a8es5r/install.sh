#!/bin/bash

function box_out()
{
  local s=("$@") b w
  for l in "${s[@]}"; do
    ((w<${#l})) && { b="$l"; w="${#l}"; }
  done
  tput setaf 3
  echo " -${b//?/-}-
| ${b//?/ } |"
  for l in "${s[@]}"; do
    printf '| %s%*s%s |\n' "$(tput setaf 2)" "-$w" "$l" "$(tput setaf 3)"
  done
  echo "| ${b//?/ } |
 -${b//?/-}-"
  tput sgr 0
}
box_out 'Is locked'  'Is locked ' 'Is locked' 'Is locked' 'Is locked'
echo ""
echo ""
echo -en "\033[0;32m 12kl3pk213p213213123213 \033[0m"
echo ""
echo ""
echo -en "\033[37;1;213213213213 \033[0m"
echo ""
echo -en "\033[37;1;44m Is locked\033[0m"
echo ""
echo ""
echo -en "\033[37;1;41m Is locked \033[0m"
echo ""
echo -en "\033[37;1;41m Is locked \033[0m"
echo ""
echo ""
 echo ""
echo ""
echo ""
echo -e "\033[0;32m Is locked  \033[0m"
echo ""
echo ""
echo -e "\033[0;33m 64 \033[0m"
read network

if [[ $network == *"::/48"* ]]
then
    mask=48
elif [[ $network == *"::/64"* ]]
then
    mask=64
else
    echo -e "\033[0;31m n. Is locked \033[0m"
    exit 1
fi
echo -e "\033[0;33m Is locked \033[0m"

read MAXCOUNT
THREADS_MAX=`sysctl kernel.threads-max|awk '{print $3}'`
MAXCOUNT_MIN=$(( MAXCOUNT-200 ))
if (( MAXCOUNT_MIN > THREADS_MAX )); then
    echo "kernel.threads-max = $THREADS_MAX belirtilen adres sayısı için bu yeterli degil!"
fi
echo ""
echo -e "\033[0;33m n Lock Error \033[0m"
read user_gerekmi
echo ""
if [[ "$user_gerekmi" != 5 ]]
    then
echo -e "\033[0;33m Lock Error \033[0m"
read proxy_login
echo -e "\033[0;33m Error.. \033[0m"
read proxy_pass
else
proxy_login=2
proxy_pass=2
fi
echo -e "\033[0;33m  Error.. \033[0m"
read proxy_port3
echo ""
echo -e "\033[0;33m Error 594.59 \033[0m"
read adresyenile2

echo -e "\033[0;33m Error \033[0m"
read ethernetnames

echo -e "\033[0;33m İpv6 Error \033[0m"
read serveripv6
echo ""

if [[ "$ethernetname" != 0 ]]
    then

ethernetdevice=${ethernetname}

fi

if [[ "$ethernetname" = 0 ]]
    then
ethernetdevice="eth0"
	
fi


yes '' |apt-get update
yes '' |apt-get install "gcc++" git make screen mc wget
yes '' |apt-get install psmisc
yes '' |apt-get install build-essential
echo ""
echo ""
echo ""
base_net=`echo $network | awk -F/ '{print $1}'`
echo -e "\033[0;32m $base_net ağı için $mask maskesi olan bir proxy server kurma. \033[0m"
sleep 2
echo ""
echo ""
echo -e "\033[0;32m Temel bir IPv6 adresi kurma \033[0m"
echo ""
echo ""
ip -6 addr add ${base_net}2 peer ${base_net}1 dev ${ethernetdevice}
sleep 5
ip -6 route add default via ${base_net}1 dev ${ethernetdevice}
ip -6 route add local ${base_net}/${mask} dev lo
echo ""
echo ""
echo -e "\033[0;33m IPv6 bağlantısını kontrol ediliyor ... \033[0m"
echo ""
echo ""
if ping6 -c3 google.com &> /dev/null
then
    echo -e "\033[0;32m başarılı \033[0m"
else
    echo -e "\033[0;31m Uyarı: IPv6 bağlantısı çalışmıyor! \033[0m"
fi
echo ""
CDIR="$(pwd)"
echo ""
echo ""
echo -e "\033[0;33m Yürütülebilir dosyaları kopyalama \033[0m"
echo ""
rm -f /usr/local/bin/ndppd
rm -f /usr/local/bin/3proxy

cp $CDIR/3proxy /usr/local/bin/
cp $CDIR/ndppd /usr/local/bin/
echo ""
rm -rf /root/3proxy
rm -rf  /root/ndppd
echo ""
cd ~
git clone https://github.com/DanielAdolfsson/ndppd.git
cd ~/ndppd
make all && make install
cd ~
echo ""
git clone https://github.com/z3APA3A/3proxy.git
rm -f /root/3proxy/src/proxy.h
cp $CDIR/proxy.h /root/3proxy/src/
cd 3proxy/
make -f Makefile.Linux
cd ~
echo -e "\033[0;33m Çekirdek yapılandırma \033[0m"
echo ""
cd /tmp
wget http://kernel.ubuntu.com/~kernel-ppa/mainline/v4.3-wily/linux-headers-4.3.0-040300_4.3.0-040300.201511020949_all.deb
wget http://kernel.ubuntu.com/~kernel-ppa/mainline/v4.3-wily/linux-headers-4.3.0-040300-generic_4.3.0-040300.201511020949_amd64.deb
wget http://kernel.ubuntu.com/~kernel-ppa/mainline/v4.3-wily/linux-image-4.3.0-040300-generic_4.3.0-040300.201511020949_amd64.deb

dpkg -i linux-headers-4.3*.deb linux-image-4.3*.deb
update-grub
echo ""
echo -e "\033[0;33m Depo güncelleniyor ... \033[0m"
echo ""
dpkg -l|grep linux-image|grep "\-4\."
if [ $? -eq 0 ]
then
    echo -e "\033[0;33m Yeni çekirdek askıda klamış durumda, manuel yeniden başlatma gerekli! \033[0m"
else
    echo -e "\033[0;32m  Uyarı: 4.x çekirdek yüklenmemiş! \033[0m"
fi
echo ""
cd ~
echo ""
echo -e "\033[0;33m Ndppd Dosyasını yapılandırma \033[0m"
echo ""
mkdir -p /root/ndppd/
rm -f /root/ndppd/ndppd.conf
cp $CDIR/ndppd.conf /root/ndppd/
sed -i "s/__NETWORK__/${base_net}\/${mask}/" /root/ndppd/ndppd.conf
sed -i "s/__ETHER__/${ethernetdevice}/" /root/ndppd/ndppd.conf
ndppd -d -c /root/ndppd/ndppd.conf
echo ""
echo -e "\033[0;33m Veriler Kaydediliyor... \033[0m"
echo ""
echo -e "\033[0;33m Otomatik çalışma dosyaları hazırlanıyor... \033[0m"
echo ""
rm -f /root/3proxy.sh
cp $CDIR/3proxy.sh /root/
chmod +x /root/3proxy.sh
echo ""
echo -e "\033[0;33m Otomatik çalışma dosyaları çıkarılıyor... \033[0m"
echo ""
rm -f /root/random.sh
cp $CDIR/random.sh /root/
chmod +x /root/random.sh
echo ""
echo -e "\033[0;33m Otomatik çalışma dosyaları işleniyor... \033[0m"
echo ""
rm -f /root/rotatet.sh
cp $CDIR/rotatet.sh /root/
chmod +x /root/rotatet.sh
echo ""
echo -e "\033[0;33m Otomatik çalışma dosyaları tamamlanıyor...\033[0m"
echo ""
firstntwrk=`echo $base_net|awk -F:: '{print $1}'`
ip6addr=${serveripv6}
echo ""
rm -f /root/veriler.list
cp $CDIR/veriler.list /root/
chmod +x /root/veriler.list
echo ""
sed -i "s/__NETWORK__/${firstntwrk}/" /root/veriler.list
sed -i "s/__SUBNET__/${mask}/" /root/veriler.list
sed -i "s/__PROXYADET__/${MAXCOUNT}/" /root/veriler.list
sed -i "s/__PROXYLOGN__/${proxy_login}/" /root/veriler.list
sed -i "s/__PROXYPASS__/${proxy_pass}/" /root/veriler.list
sed -i "s/__PROXYSTRTPORT__/${proxy_port}/" /root/veriler.list
sed -i "s/__PROXYMNTE__/${adresyenile}/" /root/veriler.list
sed -i "s/__SUNUCUADRES__/${ip4addr}/" /root/veriler.list
sed -i "s/__ETHERNET__/${ethernetdevice}/" /root/veriler.list
echo ""
echo -e "\033[0;33m 3proxy server yapılandırma... \033[0m"
echo ""
rm -f /root/ip.list
echo -e "\033[0;33m $MAXCOUNT Adet IPV6 Adres Oluşturma \033[0m"
array=( 1 2 3 4 5 6 7 8 9 0 a b c d e f )
count=1
first_blocks=`echo $base_net|awk -F:: '{print $1}'`
rnd_ip_block ()
{
    a=${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}
    b=${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}
    c=${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}
    d=${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}
    if [[ "x"$mask == "x48" ]]
    then
        e=${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}
        echo $first_blocks:$a:$b:$c:$d:$e >> /root/ip.list
    else
        echo $first_blocks:$a:$b:$c:$d >> /root/ip.list
    fi
}
while [ "$count" -le $MAXCOUNT ]
do
        rnd_ip_block
        let "count += 1"
done
echo ""
echo -e "\033[0;33m 3proxy Yapılandırma sonlandırılıyor... \033[0m"
echo ""
mkdir -p /root/3proxy
cat >/root/3proxy/3proxy.cfg <<EOL
daemon
nserver 8.8.4.4
nserver 8.8.8.8
nscache 65536
timeouts 1 5 30 60 180 1800 15 60
setgid 65535
setuid 65535
flush
auth strong
users ${proxy_login}:CL:${proxy_pass}
allow ${proxy_login}
authcache ${proxy_login} 60
EOL

echo >> /root/3proxy/3proxy.cfg
ip4_addr=${serveripv4}
port=${proxy_port}
count=1
for i in `cat /root/ip.list`; do
    echo "proxy -6 -n -a -p$port -i$ip4_addr -e$i" >> /root/3proxy/3proxy.cfg
    ((port+=1))
    ((count+=1))
done
echo ""
echo -e "\033[0;33m Sysctl dosyası yapılandırılıyor... \033[0m"
echo ""
echo "net.ipv6.conf.${ethernetdevice}.proxy_ndp=1" >> /etc/sysctl.conf
echo "net.ipv6.conf.all.proxy_ndp=1" >> /etc/sysctl.conf
echo "net.ipv6.conf.default.forwarding=1" >> /etc/sysctl.conf
echo "net.ipv6.conf.all.forwarding=1" >> /etc/sysctl.conf
echo "net.ipv6.ip_nonlocal_bind=1" >> /etc/sysctl.conf
echo "vm.max_map_count=95120" >> /etc/sysctl.conf
echo "kernel.pid_max=95120" >> /etc/sysctl.conf
echo "net.ipv4.ip_local_port_range=1024 65000" >> /etc/sysctl.conf
sysctl -p
echo ""
crontab -r

if [[ "$adresyenile" != 0 ]]
    then
( crontab -l ; echo "*/${adresyenile} * * * *  ./rotatet.sh" ) | crontab -
fi
echo ""
/root/random.sh > /root/ip.list
/root/3proxy.sh > /root/3proxy/3proxy.cfg 
killall 3proxy
/bin/kill  /3proxy.pid
/root/3proxy/bin/3proxy /root/3proxy/3proxy.cfg
clear
echo ""
echo -e "\033[0;33m Rc.local Dosyasını yapılandırılıyor... \033[0m"
echo ""
cat >/etc/rc.local <<EOL
#!/bin/bash
#
# rc.local
#
# This script is executed at the end of each multiuser runlevel.
# value on error.
#
# In order to enable or disable this script just change the execution
# bits.
#
# By default this script does nothing.
EOL

echo >> /etc/rc.local
sed -i '/exit 0/d' /etc/rc.local
sed -i 's/#!\/bin\/sh\ -e/#!\/bin\/bash/' /etc/rc.local
echo "ulimit -n 600000" >> /etc/rc.local
echo "ulimit -u 600000" >> /etc/rc.local
echo "ip -6 addr add ${base_net}2 peer ${base_net}1 dev ${ethernetdevice}" >> /etc/rc.local
echo "sleep 5" >> /etc/rc.local
echo "ip -6 route add default via ${base_net}1 dev ${ethernetdevice}" >> /etc/rc.local
echo "ip -6 route add local ${base_net}/${mask} dev lo" >> /etc/rc.local
echo "ndppd -d -c /root/ndppd/ndppd.conf" >> /etc/rc.local

if [[ "$adresyenile" != 0 ]]
    then

echo "/root/rotatet.sh" >> /etc/rc.local

fi

if [[ "$adresyenile" = 0 ]]
    then

echo "killall 3proxy" >> /etc/rc.local
echo "/bin/kill  /3proxy.pid" >> /etc/rc.local
echo "/root/3proxy/bin/3proxy /root/3proxy/3proxy.cfg" >> /etc/rc.local
	
fi

echo -e "\nexit 0\n" >> /etc/rc.local
chmod +x /etc/rc.local
echo ""
echo ""
echo -en "\033[37;1;42m Yapılandırma tamamlandı. SERVER DETAYLARI \033[0m"
echo ""
echo ""
echo -en "\033[37;1;42m SERVER DETAYLARI | ${ip4addr}:${proxy_port}:${proxy_login}:${proxy_pass} Toplam Port Sayısı : ${MAXCOUNT} \033[0m"
echo ""
echo ""
echo -en "\033[37;1;41m YENİDEN BAŞLATMA GEREKLİ! \033[0m"
echo ""
exit 0

